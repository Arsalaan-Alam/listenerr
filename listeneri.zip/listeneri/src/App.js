import logo from './logo.svg';
import './App.css';

function App() {
  return (
   
    <div class="container">
  
    <div class="heading">
    LISTENERR 
</div>
<div class="wrap">
    <div class="search">
       <input type="text" class="searchterm" placeholder="Enter The Link" >
     </input>
    </div>
    
    </div>
    <button type="submit" class="searchButton" onclick="window.location.href = 'player.html';">
        GO
            </button>
       <div class="conatinerin">

</div>
</div>

  );
}

export default App;
